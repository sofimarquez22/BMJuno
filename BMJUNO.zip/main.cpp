#include <iostream>
#include "UnoGame.hpp"
using namespace std;

int main(){
    //creating an Uno Game instance
    UnoGame game;

    game.play();
	
    return 0;
}
